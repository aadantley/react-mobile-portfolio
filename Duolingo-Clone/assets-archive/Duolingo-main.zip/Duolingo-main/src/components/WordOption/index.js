export { default } from "./WordOption";
