export { default } from "./ImageMultipleChoiceQuestion";
