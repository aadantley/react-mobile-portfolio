export default [
  {
    id: "q5",
    type: "OPEN_ENDED",
    text: "Yo soy un hombre",
    answer: "I am a man",
  },
  {
    id: "q5",
    type: "OPEN_ENDED",
    text: "La mujer",
    answer: "the woman",
  },
  {
    id: "q5",
    type: "OPEN_ENDED",
    text: "Me gusta React Native",
    answer: "I like react native",
  },
];
